import type { Movie } from "../types";
import fallbackMovies from "../data/movies.json";

const API_BASE = (
  import.meta.env.VITE_API_BASE_URL as string | undefined
)?.replace(/\/$/, "");

const TIMEOUT_MS = 6000;

export async function fetchMovies(signal?: AbortSignal): Promise<Movie[]> {
  if (!API_BASE) return fallbackMovies as Movie[];

  const timeout = new AbortController();
  const timer = window.setTimeout(() => timeout.abort(), TIMEOUT_MS);
  const onAbort = () => timeout.abort();
  signal?.addEventListener("abort", onAbort);

  try {
    const response = await fetch(`${API_BASE}/movies`, {
      signal: timeout.signal,
      headers: { Accept: "application/json" },
    });
    if (!response.ok) throw new Error(`Movies API failed (${response.status})`);
    const data: unknown = await response.json();
    if (!Array.isArray(data))
      throw new Error("Movies API must return an array");
    return data as Movie[];
  } finally {
    window.clearTimeout(timer);
    signal?.removeEventListener("abort", onAbort);
  }
}